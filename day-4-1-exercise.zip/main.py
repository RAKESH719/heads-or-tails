#Write your code below this line 👇
#Hint: Remember to import the random module first. 🎲

import random
randomInteger=random.randint(0,1)
if randomInteger==1:
 print("Heads")
else:
  print("Tails")







